//
//  NewLocationApp.swift
//  NewLocation
//
//  Created by joan Barrull on 27/02/2024.
//

import SwiftUI

@main
struct NewLocationApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
